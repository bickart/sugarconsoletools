<?php
$manifest = array (
  'id' => 'POWERHOUR_SUGAR_DEVELOPERS_TOOLS',
  'name' => 'PowerHour | Sugar Console Developers Tools',
  'description' => 'Adds developer tools to the SugarCRM Console',
  'version' => '1.0.2',
  'author' => 'Jeff Bickart',
  'is_uninstallable' => 'true',
  'published_date' => '2022-05-13 13:28:53',
  'type' => 'module',
  'remove_tables' => '',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '11\\.(.*?)\\.(.*?)',
      1 => '12\\.(.*?)\\.(.*?)',
      2 => '13\\.(.*?)\\.(.*?)',
      3 => '14\\.(.*?)\\.(.*?)',
      4 => '15\\.(.*?)\\.(.*?)',
      5 => '16\\.(.*?)\\.(.*?)',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'ENT',
  ),
);
$installdefs = array (
  'id' => 'POWERHOUR_SUGAR_DEVELOPERS_TOOLS',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/crm/custom/Extension/application/Ext/Console/RegisterQuickRepairCommand.php',
      'to' => 'custom/Extension/application/Ext/Console/RegisterQuickRepairCommand.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/crm/custom/src/Console/Command/QuickRepairCommand.php',
      'to' => 'custom/src/Console/Command/QuickRepairCommand.php',
    ),
  ),
);
